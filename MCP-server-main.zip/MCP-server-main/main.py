#!/usr/bin/env python3
import os
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, PlainTextResponse

# --------------------------------------------------------------------------------------
# Config & Setup
# --------------------------------------------------------------------------------------

app = FastAPI(title="Cubane MCP Server", version="0.4.0")

SPEC_DIR = Path(os.getenv("SPEC_DIR", "./specs")).resolve()
GRAPH_DIR = Path(os.getenv("GRAPH_DIR", "./graphs")).resolve()
SPEC_DIR.mkdir(parents=True, exist_ok=True)
GRAPH_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
log = logging.getLogger("mcp")

# --------------------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------------------

def list_specs() -> List[Path]:
    """Return all .md spec files, sorted by name."""
    return sorted(SPEC_DIR.glob("*.md"))

def jsonrpc_ok(id_value: Any, result: Dict[str, Any]) -> JSONResponse:
    return JSONResponse({"jsonrpc": "2.0", "id": id_value, "result": result})

def jsonrpc_err(id_value: Any, code: int, message: str) -> JSONResponse:
    return JSONResponse({"jsonrpc": "2.0", "id": id_value, "error": {"code": code, "message": message}})

def spec_uri_for(filename: str) -> str:
    return f"spec://file/{filename}"

# --------------------------------------------------------------------------------------
# Optional: health check (handy during local dev)
# --------------------------------------------------------------------------------------

@app.get("/healthz")
def healthz():
    return PlainTextResponse("ok")

# --------------------------------------------------------------------------------------
# MCP JSON-RPC Endpoint
# --------------------------------------------------------------------------------------

@app.post("/")
async def mcp_handler(request: Request):
    body = await request.json()
    method: Optional[str] = body.get("method")
    req_id = body.get("id")

    log.info("📥 Incoming MCP Request: %s", method)
    log.debug("Body: %s", body)

    # ---------------------------------- initialize -----------------------------------
    if method == "initialize":
        return jsonrpc_ok(req_id, {
            "capabilities": {
                "tools": True,
                "resources": True,
                "prompts": False
            },
            "serverInfo": {"name": "Cubane MCP Server", "version": "0.4.0"}
        })

    # ---------------------------------- tools/list -----------------------------------
    if method == "tools/list":
        return jsonrpc_ok(req_id, {
            "tools": [
                {
                    "name": "provide_specs_context",
                    "description": "List available spec resources (URIs) with light metadata",
                    "input_schema": {"type": "object", "properties": {}}
                },
                {
                    "name": "read_spec_chunk",
                    "description": "Read a slice of a spec by filename + byte range",
                    "input_schema": {
                        "type": "object",
                        "properties": {
                            "filename": {"type": "string"},
                            "start": {"type": "integer", "minimum": 0},
                            "max_bytes": {"type": "integer", "minimum": 1, "maximum": 65536}
                        },
                        "required": ["filename"]
                    }
                }
            ]
        })

    # ------------------------------- resources/list ----------------------------------
    if method == "resources/list":
        resources = []
        for f in list_specs():
            resources.append({
                "uri": spec_uri_for(f.name),
                "name": f.name,
                "title": f.name,
                "mimeType": "text/markdown"
            })
        return jsonrpc_ok(req_id, {"resources": resources})

    # ------------------------------- resources/read ----------------------------------
    if method == "resources/read":
        params = body.get("params", {}) or {}
        uri = params.get("uri", "")

        if not isinstance(uri, str) or not uri.startswith("spec://file/"):
            return jsonrpc_err(req_id, -32602, "Unsupported or missing URI")

        filename = uri.split("spec://file/", 1)[1].split("#", 1)[0]
        path = (SPEC_DIR / filename)
        if not path.exists():
            return jsonrpc_err(req_id, -32602, f"Not found: {filename}")

        try:
            text = path.read_text(encoding="utf-8")
        except Exception as e:
            return jsonrpc_err(req_id, -32000, f"Error reading file: {e}")

        return jsonrpc_ok(req_id, {
            "contents": [{
                "uri": uri,
                "mimeType": "text/markdown",
                "text": text
            }]
        })

    # ---------------------------------- tools/call -----------------------------------
    if method == "tools/call":
        params = body.get("params", {}) or {}
        tool = params.get("name")
        args = params.get("arguments", {}) or {}

        # --------------------------- provide_specs_context ----------------------------
        if tool == "provide_specs_context":
            entries = []
            for f in list_specs():
                try:
                    entries.append({
                        "filename": f.name,
                        "uri": spec_uri_for(f.name),
                        "size": f.stat().st_size
                    })
                except Exception as e:
                    entries.append({
                        "filename": f.name,
                        "uri": spec_uri_for(f.name),
                        "size": -1,
                        "error": str(e)
                    })

            result = {
                "content": [{
                    "type": "text",
                    "text": json.dumps({
                        "count": len(entries),
                        "generated_at": datetime.utcnow().isoformat() + "Z",
                        "specs": entries
                    }, ensure_ascii=False)
                }]
            }
            return jsonrpc_ok(req_id, result)

        # -------------------------------- read_spec_chunk ----------------------------
        if tool == "read_spec_chunk":
            filename: str = args.get("filename")
            start: int = int(args.get("start", 0))
            max_bytes: int = int(args.get("max_bytes", 1048576))

            if not filename:
                return jsonrpc_err(req_id, -32602, "filename is required")

            path = (SPEC_DIR / filename)
            if not path.exists():
                return jsonrpc_ok(req_id, {"content": [{"type": "text", "text": f"⚠️ Not found: {filename}"}]})

            try:
                blob = path.read_bytes()
                slice_bytes = blob[start:start + max_bytes]
                text = slice_bytes.decode("utf-8", errors="replace")
            except Exception as e:
                return jsonrpc_err(req_id, -32000, f"Error reading chunk: {e}")

            return jsonrpc_ok(req_id, {"content": [{"type": "text", "text": text}]})

        # -------------------------------- unknown tool -------------------------------
        return jsonrpc_ok(req_id, {"content": [{"type": "text", "text": f"⚠️ Unknown tool: {tool}"}]})

    # ---------------------------------- fallback ------------------------------------
    return jsonrpc_err(req_id, -32601, f"Unknown method {method}")

# --------------------------------------------------------------------------------------
# Entrypoint
# --------------------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn

    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8765"))
    uvicorn.run("main:app", host=host, port=port, reload=os.getenv("RELOAD", "true").lower() == "true")
