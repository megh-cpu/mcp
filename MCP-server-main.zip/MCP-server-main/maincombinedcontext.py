import os
import json
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from datetime import datetime
from pathlib import Path

app = FastAPI()

# Directories
SPEC_DIR = os.getenv("SPEC_DIR", "./specs")
GRAPH_DIR = os.getenv("GRAPH_DIR", "./graphs")
os.makedirs(GRAPH_DIR, exist_ok=True)


@app.post("/")
async def mcp_handler(request: Request):
    body = await request.json()
    method = body.get("method")
    req_id = body.get("id")

    print(f"\n📥 Incoming MCP Request: {method}")
    print("Body:", body)

    # --- initialize ---
    if method == "initialize":
        response = {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "capabilities": {"tools": True},
                "serverInfo": {"name": "Cubane MCP Server", "version": "0.3.0"}
            }
        }
        print("📤 Response:", response)
        return JSONResponse(response)

    # --- tools/list ---
    if method == "tools/list":
        response = {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "tools": [
                    {
                        "name": "summarize_spec",
                        "description": "Summarize a spec file from ./specs",
                        "input_schema": {
                            "type": "object",
                            "properties": {"filename": {"type": "string"}},
                            "required": ["filename"]
                        }
                    },
                    {
                        "name": "generate_mindmap",
                        "description": "Generate a Mermaid mindmap from a spec file and save it under ./graphs",
                        "input_schema": {
                            "type": "object",
                            "properties": {"filename": {"type": "string"}},
                            "required": ["filename"]
                        }
                    },
                    {
                        "name": "provide_specs_context",
                        "description": "Enumerate all .md spec files and return their contents in JSON format",
                        "input_schema": {
                            "type": "object",
                            "properties": {},
                            "required": []
                        }
                    }
                ]
            }
        }
        print("📤 Response:", response)
        return JSONResponse(response)

    # --- tools/call ---
    if method == "tools/call":
        params = body.get("params", {})
        tool = params.get("name")
        args = params.get("arguments", {})

        # Tool: summarize_spec
        if tool == "summarize_spec":
            filename = args.get("filename")
            path = os.path.join(SPEC_DIR, filename)
            if not os.path.exists(path):
                result = {
                    "content": [
                        {"type": "text", "text": f"⚠️ Spec not found: {filename}"}
                    ]
                }
            else:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                summary = content[:500] + "..." if len(content) > 500 else content
                result = {
                    "content": [
                        {"type": "text", "text": summary}
                    ]
                }

        # Tool: generate_mindmap
        elif tool == "generate_mindmap":
            filename = args.get("filename")
            path = os.path.join(SPEC_DIR, filename)
            if not os.path.exists(path):
                result = {
                    "content": [
                        {"type": "text", "text": f"⚠️ Spec not found: {filename}"}
                    ]
                }
            else:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()

                lines = [line.strip() for line in content.splitlines() if line.strip()]
                root = filename.replace(".md", "").replace(".txt", "")
                mermaid = [f"mindmap", f"  root(({root}))"]

                for line in lines[:15]:
                    mermaid.append(f"    {line[:40]}")

                mermaid_code = "```mermaid\n" + "\n".join(mermaid) + "\n```"
                out_file = os.path.join(GRAPH_DIR, f"{root}_mindmap.mmd")

                with open(out_file, "w", encoding="utf-8") as f:
                    f.write("\n".join(mermaid))

                result = {
                    "content": [
                        {"type": "text", "text": mermaid_code}
                    ],
                    "meta": {"saved_to": out_file}
                }

        # Tool: provide_specs_context
        elif tool == "provide_specs_context":
            specs_path = Path(SPEC_DIR)
            entries = []
            for f in sorted(specs_path.glob("*.md")):
                try:
                    entries.append({
                        "filename": f.name,
                        "content": f.read_text(encoding="utf-8")
                    })
                except Exception as e:
                    entries.append({
                        "filename": f.name,
                        "content": f"⚠️ Error reading file: {str(e)}"
                    })

            result = {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps({"specs": entries}, ensure_ascii=False)
                    }
                ],
                "meta": {
                    "count": len(entries),
                    "generated_at": datetime.utcnow().isoformat() + "Z"
                }
            }

        else:
            result = {
                "content": [
                    {"type": "text", "text": f"⚠️ Unknown tool: {tool}"}
                ]
            }

        response = {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": result
        }
        print("📤 Response:", response)
        return JSONResponse(response)

    # --- fallback ---
    response = {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {
            "code": -32601,
            "message": f"Unknown method {method}"
        }
    }
    print("📤 Response:", response)
    return JSONResponse(response)

