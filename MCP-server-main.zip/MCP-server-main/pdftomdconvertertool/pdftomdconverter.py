# convert_pdfs_to_md.py
import os
import sys
from pathlib import Path
import pdfplumber
from markdownify import markdownify as md

def pdf_to_markdown(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        text = ""
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n\n"
    return md(text)

def convert_folder(pdf_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    pdf_files = [f for f in os.listdir(pdf_folder) if f.endswith(".pdf")]

    if not pdf_files:
        print("❌ No PDF files found.")
        return

    for file in pdf_files:
        pdf_path = os.path.join(pdf_folder, file)
        md_path = os.path.join(output_folder, Path(file).stem + ".md")
        
        print(f"📄 Converting: {file}")
        markdown = pdf_to_markdown(pdf_path)
        
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(markdown)
        print(f"✅ Saved: {md_path}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python convert_pdfs_to_md.py <pdf_folder_path> <output_folder_path>")
        sys.exit(1)

    pdf_folder = sys.argv[1]
    output_folder = sys.argv[2]
    convert_folder(pdf_folder, output_folder)

