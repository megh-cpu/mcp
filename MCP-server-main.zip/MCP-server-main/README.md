# MCP-server
The MCP Protocol Server is the core backend service powering the Cubane AI-Powered Architecture Assistant Plugin, enabling automated, modular, and validated architecture design workflows across VS Code and Github Copilot.


# Cubane MCP Server

This project provides a **Model Context Protocol (MCP) server** for managing Cubane specifications, generating summaries, and building dependency mindmaps. It is designed to integrate with **VS Code, Obsidian, or GitHub Copilot MCP clients**.

---

## 📌 Features

- **Summarize Spec** – Generate a quick summary of any `.md` spec file.  
- **Provide Specs Context** – Enumerate all `.md` spec files in `/specs` and return their content as JSON (MCP-friendly format).  

---

## 📂 Project Structure

├── main.py # FastAPI MCP server
├── requirements.txt # Python dependencies
├── specs/ # Place your .md spec files here
│ └── example.md
├── graphs/ # Generated mindmaps are stored here
└── README.md


---

## ⚙️ Installation

1. Clone this repository:
   ```bash
   git clone https://github.com/<your-org>/<your-repo>.git
   cd <your-repo>

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt


🚀 Running the MCP Server

Start the server with:

uvicorn main:app --reload --port 8000


🧪 Example Curl Calls

Provide specs context:

curl -X POST http://localhost:8000/   -H "Content-Type: application/json"   -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"provide_specs_context","arguments":{}}}'


  
 
  🚀 Setting up MCP Context Server with GitHub Copilot in VS Code
1. Make Sure Your MCP Server Runs

You already have a Python MCP server (main.py) with FastAPI/uvicorn.
First, run it locally:

cd /root/mcp-server
source .venv/bin/activate   # make sure venv is active
uvicorn main:app --reload --port 8000 --host 127.0.0.1


➡️ This gives you a local endpoint at:
http://127.0.0.1:8000

2. Add MCP Config in VS Code

You need to tell VS Code + Copilot Chat about your server.

In VS Code, press Ctrl+Shift+P (or Cmd+Shift+P on Mac).

Search for: MCP: Add Server.

Choose HTTP (SSE) since uvicorn serves over HTTP.

Fill in:

Server ID: cubane

URL: http://127.0.0.1:8000

Scope: Workspace (creates .vscode/mcp.json) or User (global).

3. Example .vscode/mcp.json

If you prefer to do it manually:

{
  "servers": {
    "cubane": {
      "type": "http",
      "url": "http://127.0.0.1:8000"
    }
  }
}


👉 Save this in your repo under .vscode/mcp.json.

4. Restart VS Code + Enable in Copilot

Restart VS Code.

Open Copilot Chat (sidebar).

Make sure Agent Mode is enabled.

Click the wrench icon (Select tools) → enable cubane.

5. Using It

Now you can talk to your server directly in Copilot:

Command to give in copilot chat window -

copilot tools call provide_specs_context --server http://localhost:8000 @copilot generate new mindmap dral layer spec mindmap.json {
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Cubane Architecture Mind-Map",
  "type": "object",
  "required": ["Components"],
  "properties": {
    "Components": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["Component", "SubComponents"],
        "properties": {
          "Component": { "type": "string" },
          "SubComponents": {
            "type": "array",
            "items": {
              "type": "object",
              "required": ["SubComponent", "IndividualContracts"],
              "properties": {
                "SubComponent": { "type": "string" },
                "IndividualContracts": {
                  "type": "array",
                  "items": { "type": "string" },
                  "minItems": 1
                }
              }
            },
            "minItems": 1
          }
        }
      }
    }
  }
}
generate mermaid view also generate dependancy graph also
specs from context give citation also
  
  
Visualise .mmd files at 
- https://www.mermaidchart.com/

To convert pdf file to md format use - 
cd pdftomdconvertertool
python3 pdftomdconverter.py /home/cccm-project/inputpdfs /home/cccm-project/specs


# To fetch context in chunks for each file (Main algorithm) -

use following command -
Call MCP tool provide_specs_context on --server http://localhost:8000. Then fetch each URI via resources/read @copilot generate new mindmap dral layer spec mindmap.json {
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Cubane Architecture Mind-Map",
  "type": "object",
  "required": ["Components"],
  "properties": {
    "Components": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["Component", "SubComponents"],
        "properties": {
          "Component": { "type": "string" },
          "SubComponents": {
            "type": "array",
            "items": {
              "type": "object",
              "required": ["SubComponent", "IndividualContracts"],
              "properties": {
                "SubComponent": { "type": "string" },
                "IndividualContracts": {
                  "type": "array",
                  "items": { "type": "string" },
                  "minItems": 1
                }
              }
            },
            "minItems": 1
          }
        }
      }
    }
  }
}
generate mermaid view also generate dependancy graph also
specs from context give citation also



# Copilot Prompt Command for including external blockchain sources/context together with Cubane context

Prompts to run in order - 

1)
Call MCP tool provide_specs_context on --server http://localhost:8000. Then fetch each URI via resources/read REAd all files for context dont miss any file use public blockchain repository documentation specs on the web for context as well use all context @copilot  generate new mindmap interoperability layer spec mindmap.json { "$schema": "http://json-schema.org/draft-07/schema#", "title": "Cubane Architecture Mind-Map", "type": "object", "required": ["Components"], "properties": { "Components": { "type": "array", "items": { "type": "object", "required": ["Component", "SubComponents"], "properties": { "Component": { "type": "string" }, "SubComponents": { "type": "array", "items": { "type": "object", "required": ["SubComponent", "IndividualContracts"], "properties": { "SubComponent": { "type": "string" }, "IndividualContracts": { "type": "array", "items": { "type": "string" }, "minItems": 1 } } }, "minItems": 1 } } } } } } generate mermaid view also generate dependancy graph also specs from context give citation also generate  one-pager generation with mandatory fields:


Expected Input


Probabilistic Output


Format & Parameters


Failure Modes


ICD


Specs


File Management


Machine-readable YAML/JSON spec format with human-readable Markdown

2)if mindmap schema is coming different run - 
fix schema of mindmap.json preserving content to "$schema": "http://json-schema.org/draft-07/schema#", "title": "Cubane Architecture Mind-Map", "type": "object", "required": ["Components"], "properties": { "Components": { "type": "array", "items": { "type": "object", "required": ["Component", "SubComponents"], "properties": { "Component": { "type": "string" }, "SubComponents": { "type": "array", "items": { "type": "object", "required": ["SubComponent", "IndividualContracts"], "properties": { "SubComponent": { "type": "string" }, "IndividualContracts": { "type": "array", "items": { "type": "string" }, "minItems": 1 } } }, "minItems": 1 } } } } } }

3)Prompt For ICs → 

Generate relevant and important “Independent contracts” in each “Sub-components”
Create & update the current artifacts such as one-pager, mindmap, dependency graph.

Structure of the independent contracts (apply for all the contracts mentioned previously) →
Add this information in each independent contract → {ID, name, description, purpose, interface, tags, references, functions, dependency (if any), events (What are the events that this independent contract is responsible for), reference tokens for the context extracted and used. }

Notes: 
For any factual claim, include at least one source token immediately after the sentence.
Add “the structure of the ‘Independent Contracts’” to “ALL THE” independent contracts that have been generated so far in the mind map. 



4)  Prompt For One-Pager → 

generate one-pager (attach one-pager.md file) for/to each “Independent contracts” that has been mentioned in the mindmap.

One-pager generation with mandatory fields: 

Contract/independent contract Name & Identifier
Purpose & Role
Expected Input*
Probabilistic Output
Format & Parameters
Failure Modes & Dependencies 
Interface Control Document (ICD)
Specs of contract/independent contract
State Machine Definition
File Management
Mocking & Testing Notes
Observability
Open Questions & Citations 




Expected deliverables structure (To each “Independent Contracts”)→


{Here’s the in-depth format (with clarifying notes for each field):

---

# 📝 contract/independent contract Specification Document (One-Pager)

### 1. contract/independent contract Name & Identifier

- Name: (Human-readable name, e.g., “Transaction Initiation Handler”)
    
- ID/Code: (Unique identifier, e.g., CCCM-A1, DRAL-B6, etc.)
    
- Parent Component: (Which main component this belongs to, A–Z)
    
- Version: (Current spec version, for tracking future upgrades)
    

---

### 2. Purpose & Role

- Description: A short but clear statement of what this submodule does in the system.
    
- Scope: Boundaries — what this submodule is responsible for and what it is not.
    

---

### 3. Expected Input

- Data Sources / Upstream Modules:
    
    - List all modules or external systems that can provide input.
        
- Input Preconditions: What must be true before input is accepted (e.g., “txn must be signed with valid private key”).
    
- Input Contract: (Describe exact schema or message type expected).
    

---

### 4. Probabilistic Output

- Primary Outputs: List possible successful outputs this module may emit.
    
- Probabilistic States: Enumerate outcomes (e.g., Success, Retry, Timeout, Fail-Silent).
    
- Downstream Consumers: Which modules use this output.
    

---

### 5. Format & Parameters

- Schema: JSON/protobuf/binary layout of messages.
    
- Data Types: Specify (int64, float32, string, byte array, cryptographic hash, etc.).
    
- Encoding: (e.g., Base58, RLP, Protobuf, Flatbuffers).
    
- Versioning: Schema version, backward compatibility notes.
    

---

### 6. Failure Modes

- Input Missing: What happens if input never arrives.
    
- Input Malformed: How invalid/malformed inputs are handled (reject, sanitize, retry).
    
- Output Rejected: If downstream refuses output, what’s the fallback.
    
- Error Handling Policy: Retry logic, backoff strategy, escalation rules.


- *Dependencies: * What are the components or sub-components or contracts/independent contracts it is dependent upon.
    

---

### 7. Interface Control Document (ICD)

- Inbound Interface: Protocols/ports/APIs this module listens to.
    
- Outbound Interface: Protocols/ports/APIs this module speaks to.
    
- Message Examples: Provide sample payloads for both input and output.
    
- Dependencies: Explicit list of modules or contracts this interface depends on.
    

---

### 8. Specs of Submodule

- Functional Specs:
    
    - Core algorithm/steps it must perform.
        
    - Example pseudocode/flowchart if necessary.
        
- Non-Functional Specs:
    
    - Performance constraints (e.g., must process X txns/sec).
        
    - Latency budget.
        
    - Resource footprint (CPU/mem/network).
        
- Security Specs:
    
    - Validation rules.
        
    - Cryptographic checks.
        
    - Attack surface & mitigations.
        

---

### 9. State Machine Definition (if applicable)

- States: Enumerate possible states of the submodule.
    
- Transitions: Rules/events that move state A → B.
    
- Termination Condition: When this submodule considers its job “done.”
    
### 9.1. File Management

- Folder Structure:
    
    - src/<submodule_name>/ (main code).
        
    - tests/<submodule_name>/ (unit/integration tests).
        
    - mocks/<submodule_name>/ (mock input/output data).
        
    - docs/<submodule_name>/ (auto-generated docs & diagrams).
        
- Config Files: Environment configs, JSON/YAML/protobuf schemas.
    
- Naming Conventions: How files, classes, and functions should be named.
    
- Build/Compile Scripts: Any required Makefiles, Dockerfiles, or scripts.
---

### 10. Mocking & Testing Notes

- Mock Input Generator: How to fake input until upstream is ready.
    
- Mock Output Validator: How to test downstream using dummy outputs.
    
- Unit Test Cases: Edge cases, failure scenarios, happy path.
    

---

### 11. Observability

- Logs: Events to log (success, error, retries).
    
- Metrics: KPIs (latency, throughput, failure count).
    
- Tracing: Distributed trace IDs for debugging across components.
    

---

### 12. Open Questions / TBD & Citations

- List unresolved design & development questions.
- Dependencies on research/experimentation.
- Things/information that are missing.
- Citation of the information or context.
    

---

### 13. Change History

- Who wrote/updated it, and when.
    
---
}

5)Audit prompt 1

Conduct an in-depth technical architecture audit of the provided “Cubane Interoperability” Layer mindmap and its subcomponents and independent contract. 
 The goal is to identify missing technical aspects, architectural weaknesses, and dependency gaps that could:
Introduce security or privacy vulnerabilities


Create networking or communication risks


Cause cross-layer or cross-contract conflicts


Undermine interoperability, replay protection, or idempotency guarantees



Scope of the Audit
Component-Level Review


Audit all top-level components for missing or incomplete modules.


Identify subcomponents or contracts that are either missing or underspecified.


Cross-Component & Cross-Layer Analysis


Detect integration conflicts between components (e.g., CCCM ↔ JetRay ↔ L2FhEX ↔ PMB).


Check for misaligned APIs, serialization mismatches, inconsistent timestamps, or data structure conflicts.


Audit cross-contract dependencies that lack defined interface contracts or trust boundaries.


Security & Cryptography Audit


Verify that all cryptographic flows (ZK, FHE, ABE, PoET, KMS, PGN) include:


Correct key lifecycle handling (rotation, revocation, threshold reconstruction)


Replay protection mechanisms


Idempotency cache or anti-replay registry


Check for missing or weak primitives (nonces, randomness sources, signature domains, time anchors).


Networking & Communication Audit


Examine JetRay, RayStream, and inter-chain relay mechanisms for:


Message ordering, duplication, and replay control


Gossip propagation guarantees and QoS enforcement


Secure relay attestation and routing proofs


Identify missing rate-limiting, DoS prevention, congestion control, and peer-identity attestation layers.


Privacy & Data Handling Audit


Review data flow between L2FhEX, PMBs, and DA Layer for potential privacy leakage.


Check for missing anonymization, redaction, or encryption layers in proofs, logs, or telemetry.


Verify attribute-based encryption (ABE) enforcement across all data mirrors and APIs.


Interoperability & Replay Protection


Identify potential cross-domain replay vulnerabilities or missing idempotency cache layers.


Confirm existence of a PoET-based timestamping service and tick synchronization across chains.


Check whether cross-chain proof verification uses unique, non-replayable commitments.


Dependency & Lifecycle Validation


Evaluate how specs, contracts, and subcomponents depend on each other.


Detect circular dependencies, orphan contracts, or inconsistent state transition expectations.


Verify if the governance or upgrade lifecycle handles versioning, migration, and rollback safely.



Deliverables
For every gap, conflict, or missing item you identify, provide:
Name / Description of the missing or conflicting component.


Impact Category: Security, Privacy, Networking, Interoperability, Cross-Layer, or Lifecycle.


Severity: Critical / High / Medium / Low.


Root Cause: Architectural omission, weak specification, or undefined dependency.


Recommendation:


What needs to be added, fixed, or restructured.


Where it should be placed in the mind map (component → subcomponent → contract).


Citations:


Reference relevant Cubane internal documents (CCCM Architecture.pdf, RayFamily Architectures.pdf, L2FhEX Concept Note v0.2.pdf, etc.)


Reference public blockchain or cryptography specifications (e.g., Ethereum PoS, Cosmos IBC, Celestia DA, ZK-STARKs, TFHE, CKKS papers).


Use inline citation tokens for traceability (e.g., `` or official RFC/academic citations).



Evaluation Criteria
Your audit should explicitly answer:
What specific technical elements are missing that could hinder secure interoperability?


What cross-layer or cross-contract inconsistencies exist that may lead to failure modes?


Are replay and idempotency properly handled across consensus, bridge, and FHE paths?


Do all communication channels enforce authenticated, ordered, and timestamped message delivery?


Are proofs, evidence bundles, and timestamps cryptographically bound and non-replayable?


Which subcomponents lack defined machine-readable contracts?



Expected Output Format
A structured report in JSON or Markdown containing:
{
  "audit_findings": [
    {
      "id": "interop.replay_protection_gap",
      "category": "Security",
      "severity": "Critical",
      "description": "Missing global idempotency registry for replay prevention across JetRay and CCCM.",
      "impact": "Cross-PMB or cross-chain replays may go undetected, leading to double execution or state divergence.",
      "recommendation": "Add 'Idempotency Cache Service' under CCCM with per-slot nonce tracking and replay logs.",
      "placement": "CCCM → Consensus Core → ReplayProtectionService",
      "citations": [
        "CCCM Architecture.pdf §4.3 PoET and Replay Handling",
        "Ethereum Yellow Paper §11 (Nonce semantics)"
      ]
    }
  ]
}


Additional Focus Areas
Security & Cryptography: FHE, ZK, ABE, KMS, PGN, PoET correctness


Replay Protection & Idempotency Cache: Nonce, tick, and epoch binding


Networking & Communication: Message propagation integrity, relayer validation, DoS control


Cross-Contract Consistency: Serialization, data structure coherence, ABI alignment


Governance & Lifecycle: Protocol upgrade compatibility, schema migrations



✅ Final Instruction
Perform a robust technical audit using the above structure.
 Focus only on real technical gaps, not superficial or documentation issues.
 Every identified issue must include citations and actionable fixes that can be directly incorporated into the Interoperability Layer mindmap


6)Audit 2

 Objective
Conduct an in-depth technical architecture audit of the provided “Each” Independent Contract. 
 The goal is to identify missing technical aspects, architectural weaknesses, and dependency gaps that could:
Introduce security or privacy vulnerabilities


Create networking or communication risks


Cause cross-layer or cross-contract conflicts


Undermine interoperability, replay protection, or idempotency guarantees



Scope of the Audit
Component-Level Review (Interaction With The Independent Contract)


Audit all top-level components for missing or incomplete modules.


Identify subcomponents or contracts that are either missing or underspecified.


Cross-Component & Cross-Layer Analysis


Detect integration conflicts between components (e.g., CCCM ↔ JetRay ↔ L2FhEX ↔ PMB).


Check for misaligned APIs, serialization mismatches, inconsistent timestamps, or data structure conflicts.


Audit cross-contract dependencies that lack defined interface contracts or trust boundaries.


Security & Cryptography Audit


Verify that all cryptographic flows (ZK, FHE, ABE, PoET, KMS, PGN) include:


Correct key lifecycle handling (rotation, revocation, threshold reconstruction)


Replay protection mechanisms


Idempotency cache or anti-replay registry


Check for missing or weak primitives (nonces, randomness sources, signature domains, time anchors).


Networking & Communication Audit


Examine JetRay, RayStream, and inter-chain relay mechanisms for:


Message ordering, duplication, and replay control


Gossip propagation guarantees and QoS enforcement


Secure relay attestation and routing proofs


Identify missing rate-limiting, DoS prevention, congestion control, and peer-identity attestation layers.


Privacy & Data Handling Audit


Review data flow between L2FhEX, PMBs, and DA Layer for potential privacy leakage.


Check for missing anonymization, redaction, or encryption layers in proofs, logs, or telemetry.


Verify attribute-based encryption (ABE) enforcement across all data mirrors and APIs.


Interoperability & Replay Protection


Identify potential cross-domain replay vulnerabilities or missing idempotency cache layers.


Confirm existence of a PoET-based timestamping service and tick synchronization across chains.


Check whether cross-chain proof verification uses unique, non-replayable commitments.


Dependency & Lifecycle Validation


Evaluate how specs, contracts, and subcomponents depend on each other.


Detect circular dependencies, orphan contracts, or inconsistent state transition expectations.


Verify if the governance or upgrade lifecycle handles versioning, migration, and rollback safely.



Deliverables
For every gap, conflict, or missing item you identify, provide:
Name / Description of the missing or conflicting component.


Impact Category: Security, Privacy, Networking, Interoperability, Cross-Layer, or Lifecycle.


Severity: Critical / High / Medium / Low.


Root Cause: Architectural omission, weak specification, or undefined dependency.


Recommendation:


What needs to be added, fixed, or restructured.


Where it should be placed in the mind map (component → subcomponent → contract).


Citations:


Reference relevant Cubane internal documents (CCCM Architecture.pdf, RayFamily Architectures.pdf, L2FhEX Concept Note v0.2.pdf, etc.)


Reference public blockchain or cryptography specifications (e.g., Ethereum PoS, Cosmos IBC, Celestia DA, ZK-STARKs, TFHE, CKKS papers).


Use inline citation tokens for traceability (e.g., `` or official RFC/academic citations).



Evaluation Criteria
Your audit should explicitly answer:
What specific technical elements are missing that could hinder secure interoperability?


What cross-layer or cross-contract inconsistencies exist that may lead to failure modes?


Are replay and idempotency properly handled across consensus, bridge, and FHE paths?


Do all communication channels enforce authenticated, ordered, and timestamped message delivery?


Are proofs, evidence bundles, and timestamps cryptographically bound and non-replayable?


Which subcomponents lack defined machine-readable contracts?



Expected Output Format
A structured report in JSON or Markdown containing:
{
  "audit_findings": [
    {
      "id": "interop.replay_protection_gap",
      "category": "Security",
      "severity": "Critical",
      "description": "Missing global idempotency registry for replay prevention across JetRay and CCCM.",
      "impact": "Cross-PMB or cross-chain replays may go undetected, leading to double execution or state divergence.",
      "recommendation": "Add 'Idempotency Cache Service' under CCCM with per-slot nonce tracking and replay logs.",
      "placement": "CCCM → Consensus Core → ReplayProtectionService",
      "citations": [
        "CCCM Architecture.pdf §4.3 PoET and Replay Handling",
        "Ethereum Yellow Paper §11 (Nonce semantics)"
      ]
    }
  ]
}


Additional Focus Areas
Security & Cryptography: FHE, ZK, ABE, KMS, PGN, PoET correctness


Replay Protection & Idempotency Cache: Nonce, tick, and epoch binding


Networking & Communication: Message propagation integrity, relayer validation, DoS control


Cross-Contract Consistency: Serialization, data structure coherence, ABI alignment


Governance & Lifecycle: Protocol upgrade compatibility, schema migrations



✅ Final Instruction
Perform a robust technical audit using the above structure.
 Focus only on real technical gaps, not superficial or documentation issues.
 Every identified issue must include citations and actionable fixes that can be directly incorporated into the Each Independent Contract.


7)Audit 3
Objective
Conduct an in-depth technical architecture audit of the provided “Each One Pager Of The Independent Contracts”. 
 The goal is to identify missing technical aspects, architectural weaknesses, and dependency gaps that could:
Introduce security or privacy vulnerabilities


Create networking or communication risks


Cause cross-layer or cross-contract conflicts


Undermine interoperability, replay protection, or idempotency guarantees



Scope of the Audit
Component-Level Review (Interaction With The Independent Contract)


Audit all top-level components for missing or incomplete modules.


Identify subcomponents or contracts that are either missing or underspecified.


Cross-Component & Cross-Layer Analysis


Detect integration conflicts between components (e.g., CCCM ↔ JetRay ↔ L2FhEX ↔ PMB).


Check for misaligned APIs, serialization mismatches, inconsistent timestamps, or data structure conflicts.


Audit cross-contract dependencies that lack defined interface contracts or trust boundaries.


Security & Cryptography Audit


Verify that all cryptographic flows (ZK, FHE, ABE, PoET, KMS, PGN) include:


Correct key lifecycle handling (rotation, revocation, threshold reconstruction)


Replay protection mechanisms


Idempotency cache or anti-replay registry


Check for missing or weak primitives (nonces, randomness sources, signature domains, time anchors).


Networking & Communication Audit


Examine JetRay, RayStream, and inter-chain relay mechanisms for:


Message ordering, duplication, and replay control


Gossip propagation guarantees and QoS enforcement


Secure relay attestation and routing proofs


Identify missing rate-limiting, DoS prevention, congestion control, and peer-identity attestation layers.


Privacy & Data Handling Audit


Review data flow between L2FhEX, PMBs, and DA Layer for potential privacy leakage.


Check for missing anonymization, redaction, or encryption layers in proofs, logs, or telemetry.


Verify attribute-based encryption (ABE) enforcement across all data mirrors and APIs.


Interoperability & Replay Protection


Identify potential cross-domain replay vulnerabilities or missing idempotency cache layers.


Confirm existence of a PoET-based timestamping service and tick synchronization across chains.


Check whether cross-chain proof verification uses unique, non-replayable commitments.


Dependency & Lifecycle Validation


Evaluate how specs, contracts, and subcomponents depend on each other.


Detect circular dependencies, orphan contracts, or inconsistent state transition expectations.


Verify if the governance or upgrade lifecycle handles versioning, migration, and rollback safely.



Deliverables
For every gap, conflict, or missing item you identify, provide:
Name / Description of the missing or conflicting component.


Impact Category: Security, Privacy, Networking, Interoperability, Cross-Layer, or Lifecycle.


Severity: Critical / High / Medium / Low.


Root Cause: Architectural omission, weak specification, or undefined dependency.


Recommendation:


What needs to be added, fixed, or restructured.


Where it should be placed in the mind map (component → subcomponent → contract).


Citations:


Reference relevant Cubane internal documents (CCCM Architecture.pdf, RayFamily Architectures.pdf, L2FhEX Concept Note v0.2.pdf, etc.)


Reference public blockchain or cryptography specifications (e.g., Ethereum PoS, Cosmos IBC, Celestia DA, ZK-STARKs, TFHE, CKKS papers).


Use inline citation tokens for traceability (e.g., `` or official RFC/academic citations).



Evaluation Criteria
Your audit should explicitly answer:
What specific technical elements are missing that could hinder secure interoperability?


What cross-layer or cross-contract inconsistencies exist that may lead to failure modes?


Are replay and idempotency properly handled across consensus, bridge, and FHE paths?


Do all communication channels enforce authenticated, ordered, and timestamped message delivery?


Are proofs, evidence bundles, and timestamps cryptographically bound and non-replayable?


Which subcomponents lack defined machine-readable contracts?



Expected Output Format
A structured report in JSON or Markdown containing:
{
  "audit_findings": [
    {
      "id": "interop.replay_protection_gap",
      "category": "Security",
      "severity": "Critical",
      "description": "Missing global idempotency registry for replay prevention across JetRay and CCCM.",
      "impact": "Cross-PMB or cross-chain replays may go undetected, leading to double execution or state divergence.",
      "recommendation": "Add 'Idempotency Cache Service' under CCCM with per-slot nonce tracking and replay logs.",
      "placement": "CCCM → Consensus Core → ReplayProtectionService",
      "citations": [
        "CCCM Architecture.pdf §4.3 PoET and Replay Handling",
        "Ethereum Yellow Paper §11 (Nonce semantics)"
      ]
    }
  ]
}


Additional Focus Areas
Security & Cryptography: FHE, ZK, ABE, KMS, PGN, PoET correctness


Replay Protection & Idempotency Cache: Nonce, tick, and epoch binding


Networking & Communication: Message propagation integrity, relayer validation, DoS control


Cross-Contract Consistency: Serialization, data structure coherence, ABI alignment


Governance & Lifecycle: Protocol upgrade compatibility, schema migrations



✅ Final Instruction
Perform a robust technical audit using the above structure.
 Focus only on real technical gaps, not superficial or documentation issues.
 Every identified issue must include citations and actionable fixes that can be directly incorporated into the Each One Pager Of The Independent Contracts.
