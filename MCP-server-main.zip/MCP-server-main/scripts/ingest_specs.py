import os
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter

SPEC_DIR = "./specs"
DB_DIR = "./data/chroma"

def ingest():
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    vectorstore = Chroma(
        persist_directory=DB_DIR,
        embedding_function=embeddings
    )

    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)

    for fname in os.listdir(SPEC_DIR):
        if fname.endswith((".md", ".txt")):
            with open(os.path.join(SPEC_DIR, fname)) as f:
                text = f.read()
            docs = splitter.create_documents([text], metadatas=[{"source": fname}])
            vectorstore.add_documents(docs)

    vectorstore.persist()
    print("✅ Ingestion complete")

if __name__ == "__main__":
    ingest()

